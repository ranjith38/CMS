<?php 
include 'admin/db_connect.php'; 

// Get the event ID from the URL
$event_id = isset($_GET['event_id']) ? intval($_GET['event_id']) : 0;

$event = $conn->query("
    SELECT e.*, v.venue, v.category, v.address 
    FROM events e 
    INNER JOIN venue v ON e.venue_id = v.id
    WHERE e.id = $event_id
")->fetch_assoc();

if (!$event) {
    die("Event not found.");
}

?>

<style>
#portfolio .img-fluid {
    width: calc(100%);
    min-height: 30vh;
    z-index: -1;
    position: relative;
    padding: 1em;
}

.carousel img {
    width: 100%; 
    height: 300px; /* Fixed height */
    object-fit: cover; /* Maintain aspect ratio without distortion */
    border-radius: 8px;
}

.carousel-inner {
    min-height: calc(100%);
    border-radius: 8px;
}

.event-details {
    background-color: #f4f4f9;
    padding: 20px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

h4, h3 {
    color: #333;
}
</style>

<div class="container-fluid mt-3 pt-2">
    <h3 class="text-center text-primary"><?php echo ucwords($event['event']) ?></h3>
    <div class="event-details">
        <p>
            <small>
                <?php echo date('d M Y, h:i A', strtotime($event['schedule'])); ?> 
                (<?php echo strtotime($event['schedule']) >= time() ? '<span style="color: green;">Upcoming</span>' : '<span style="color: red;">Completed</span>'; ?>)
            </small>
        </p>
        <p><i><?php echo $event['venue'] ?>, <?php echo $event['address'] ?></i></p>

        <!-- Display event description -->
        <p><?php echo html_entity_decode($event['description']); ?></p>
    </div>

    <!-- Carousel for event images -->
    <div id="eventCarousel" class="carousel slide mt-3" data-ride="carousel">
        <div class="carousel-inner">
            <?php
            $fpath = 'admin/assets/uploads/event_' . $event['venue_id'];
            $active = true;

            if (file_exists($fpath)) {
                $images = scandir($fpath);
                foreach ($images as $img) {
                    // Exclude system files like '.' and '..'
                    if (!in_array($img, array('.', '..'))) {
                        echo '
                        <div class="carousel-item '.($active ? 'active' : '').'">
                            <img src="'.$fpath.'/'.$img.'" class="d-block w-100" alt="Event Image">
                        </div>';
                        $active = false;
                    }
                }
            } else {
                echo '<p class="text-center">No images available for this event.</p>';
            }
            ?>
        </div>
        <a class="carousel-control-prev" href="#eventCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#eventCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <div class="text-center mt-4">
        <a href="index.php?page=events" class="btn btn-secondary">Back to Events</a>
    </div>
</div>

<!-- Bootstrap JS (if not already included) -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
