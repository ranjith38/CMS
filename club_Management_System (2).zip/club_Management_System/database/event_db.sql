-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2025 at 07:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `audience`
--

CREATE TABLE `audience` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `event_id` int(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = for verification,  1 = confirmed,2= declined',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `class` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audience`
--

INSERT INTO `audience` (`id`, `name`, `contact`, `email`, `address`, `event_id`, `status`, `date_created`, `class`) VALUES
(6, 'Nithish', '486468484', 'nithish@gmail.com', 'ganaoadjink', 9, 1, '2025-02-25 12:38:37', '3 bsc cs'),
(21, 'Ranjith Kumar', '08056434939', 'yellow56shadow90@gmail.com', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 9, 1, '2025-03-02 15:42:40', '3 bsc cs 1');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(30) NOT NULL,
  `venue_id` int(30) NOT NULL,
  `event` text NOT NULL,
  `description` text NOT NULL,
  `schedule` datetime NOT NULL,
  `banner` text NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `venue_id`, `event`, `description`, `schedule`, `banner`, `date_created`) VALUES
(9, 14, 'Plantation Drive', '\\To organize a Plantation drive as part of our eco club, (13, march) plan the date, select appropriate tree species, arrange tools and saplings, plant trees, and establish a care routine for maintenance.&nbsp;&lt;/span&gt;&lt;/font&gt;&lt;/h1&gt;', '2025-03-13 11:00:00', '1741863900_Eco-Club-Tree-Plantation-1024x758.webp', '0000-00-00 00:00:00'),
(26, 14, 'tree planing', '&lt;h1&gt;&lt;span style=&quot;font-size: 16px;&quot;&gt;To organize a Plantation drive as part of our eco club, (13, march) plan the date, select appropriate tree species, arrange tools and saplings, plant trees, and establish a care routine for maintenance.&nbsp;&lt;/span&gt;&lt;/h1&gt;', '2025-03-22 09:00:00', '1742440620_Eco-Club-Tree-Plantation-1024x758.webp', '0000-00-00 00:00:00'),
(27, 16, 'check', '&lt;p style=&quot;text-align: left;&quot;&gt;&lt;span style=&quot;text-align: left;&quot;&gt;a simple example of this paragraph&lt;/span&gt;&lt;/p&gt;', '2025-03-25 10:00:00', '', '0000-00-00 00:00:00'),
(28, 14, 'Plantation Drive', 'To organize a plantation drive as part o eco club in karur, Tamil nadu, focuson community engagement, choose appropriate tree specils, and ensure proper planning and execution, including sourcing saplings and tools, and post-planting care.', '2025-04-05 10:12:00', '1743569520_Eco-Club-Tree-Plantation-1024x758.webp', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL,
  `location` varchar(100) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `instagram` varchar(100) NOT NULL,
  `youtube` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`, `location`, `facebook`, `twitter`, `instagram`, `youtube`) VALUES
(1, 'VCSM Club Management System', 'valluvarcollege@vcsm.ac.in', '6541654646', '1742454720_479737918_1137777517886517_3598360339705214807_n.jpg', '&lt;hr class=&quot;w-100&quot; style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Times New Roman&amp;quot;; font-size: medium;&quot;&gt;&lt;p class=&quot;mb-4&quot; align=&quot;justify&quot; style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Times New Roman&amp;quot;; font-size: medium;&quot;&gt;&lt;b&gt;Valluvar College of Science and Management&lt;/b&gt;&amp;nbsp;was established in the year&amp;nbsp;&lt;b&gt;2004&lt;/b&gt;, with a magnanimous vision of creating human assets with high ethics, who would considerably contribute for the betterment of the nation. It&rsquo;s a co-educational institution affiliated to Bharathidasan University, Tiruchirappalli. The college offers&lt;b&gt;&amp;nbsp;13 Undergraduate programmes, 5 Postgraduate programmes, M.Phil and Ph.D in Commerce.&lt;/b&gt;&amp;nbsp;The college has the noble aim of enhancing the knowledge of students belonging to rural society, minorities, and economically down trodden by offering a need based education and ensuring secured placements.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;', 'Nh-7, Karur-Madurai National Highway, Puthambur (P.O) Karur-639003, Tamilnadu, India', 'https://www.facebook.com/valluvarcollege/', 'https://x.com/ValluvarCollege/status/1569912422135373824', 'https://www.instagram.com/valluvarcollege_karur/', 'https://www.youtube.com/channel/UCpt9I9NPfPOXsxit-fkSXiw');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=Admin,2=Staff'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`) VALUES
(1, 'Administrator', 'admin', '81dc9bdb52d04dc20036dbd8313ed055', 1);

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `id` int(30) NOT NULL,
  `venue` text NOT NULL,
  `category` enum('Academic','Non-Academic') NOT NULL,
  `address` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`id`, `venue`, `category`, `address`, `description`) VALUES
(6, 'Science Club', 'Academic', 'Lugesh', 'A science club is a group or organization that provides an opportunity for students and enthusiasts to explore and engage with the world of science through learning, experiments, and activitie.'),
(12, 'Maths club', 'Academic', 'naan', 'A mathematics club is an extracurricular activity focused on fostering a love for math, encouraging problem-solving, and providing a supportive environment for learning and exploring mathematical concepts outside the traditional classroom. '),
(14, 'Eco Club', 'Non-Academic', 'Nithish', 'Eco club or green club is a voluntary group which promotes the participation of students in learning about, and improving their environment. A green club is a means by which students and youth can organize themselves to learn more and this issue, and also take action to improve their immediate environment.'),
(16, 'Newspaper Club', 'Academic', 'Vetri', 'A newspaper club is a student-led organization that produces and distributes a school newspaper, offering students opportunities to learn journalism, photography, design, and other related skills while reporting on school events and local news. '),
(19, 'Sports Clubs', 'Non-Academic', 'Vivek', 'A sports club is an organization of people who share an interest in playing sports, either recreationally or competitively, and aims to promote and facilitate the practice of specific sports. '),
(20, 'communication club', 'Academic', 'Dinesh', 'A communication club is a student-led organization focused on developing and improving communication skills through various activities like workshops, debates, and mock interviews, open to all majors and backgrounds. '),
(22, 'Bookworm Club', 'Academic', 'vasanth', 'Bookworms Book Club is uLibrary\'s dedicated book club for younger listeners. A world first, Bookworms allows children to enjoy the same audiobook at the same time and discuss it not only with members of their own library, but with Bookworms members around the world.');

-- --------------------------------------------------------

--
-- Table structure for table `venue_booking`
--

CREATE TABLE `venue_booking` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `venue_id` int(30) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `datetime` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0-for verification,1=confirmed,2=canceled',
  `class` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venue_booking`
--

INSERT INTO `venue_booking` (`id`, `name`, `address`, `email`, `contact`, `venue_id`, `duration`, `datetime`, `status`, `class`) VALUES
(1, 'John Smith', 'Sample 1', 'asdasd@gmail.com', '+18456-5455-55', 1, '1 night', '2020-10-14 17:00:00', 2, 'lll Bsc cs 1'),
(2, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '08056434939', 5, '1', '2025-02-26 10:21:00', 1, ''),
(4, 'Ranj', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '08056434939', 1, '1', '0000-00-00 00:00:00', 2, ''),
(5, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '787888', 4, '', '0000-00-00 00:00:00', 0, ''),
(8, 'Ranjith Kumar', 'badsgjuadsgyju', 'gjggjygg@gmail.com', '5313465465', 7, '', '0000-00-00 00:00:00', 0, 'lll Bsc(cs)'),
(9, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '46546484', 14, '', '0000-00-00 00:00:00', 1, 'lll bsc cs 1'),
(10, 'Nithish', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'nithish@gmail.com', '5744178478', 6, '', '0000-00-00 00:00:00', 2, 'lll bsc cs'),
(11, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '+6948 8542 623', 12, '', '0000-00-00 00:00:00', 0, 'CS'),
(12, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '46546484', 6, '', '0000-00-00 00:00:00', 1, 'lll bsc cs 1'),
(13, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '08056434939', 14, '', '0000-00-00 00:00:00', 0, 'ai'),
(14, 'vasanth', 'aravakurichi,karur', 'vasanth@gmail.com', '9791674578', 17, '', '0000-00-00 00:00:00', 0, 'lll bsc cs'),
(15, 'Ravi', 'bhvv', 'ravi@gmail.com', '9626493959', 0, '', '0000-00-00 00:00:00', 0, 'lll bsc cs 1'),
(16, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '46546484', 0, '', '0000-00-00 00:00:00', 0, 'lll bsc cs'),
(17, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '46546484', 0, '', '0000-00-00 00:00:00', 0, 'lll bsc cs 1'),
(18, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '46546484', 0, '', '0000-00-00 00:00:00', 0, 'lll bsc cs 1'),
(19, 'nk', 'ubu', 'nbn@gmail.com', '84894781', 0, '', '0000-00-00 00:00:00', 0, 'huh'),
(20, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '78788', 0, '', '0000-00-00 00:00:00', 0, 'cs'),
(21, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '5879463210', 0, '', '0000-00-00 00:00:00', 0, 'CS'),
(22, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '+6948 8542 623', 0, '', '0000-00-00 00:00:00', 0, 'lll bsc cs 1'),
(23, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '5879463210', 18, '', '0000-00-00 00:00:00', 0, 'CS'),
(25, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '+6948 8542 623', 0, '', '0000-00-00 00:00:00', 0, 'lll bsc cs'),
(26, 'Ravi', 'sellandipalayam, karur', 'ravi@gmail.com', '9626493959', 0, '', '0000-00-00 00:00:00', 0, 'lll bcom'),
(27, 'rg', 'bg', 'kbj@gam', '448', 0, '', '0000-00-00 00:00:00', 0, 'bca'),
(28, 'Ranjith Kumar', '16, ganapati garden, pallwarpatti , othaiyur , thanthonimalai, karur', 'yellow56shadow90@gmail.com', '123456', 18, '', '0000-00-00 00:00:00', 0, 'bca'),
(29, 'Ravi', 'sellandipalayam, karur', 'ravi@gmail.com', '9626493959', 12, '', '0000-00-00 00:00:00', 0, 'bcom');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audience`
--
ALTER TABLE `audience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `venue_booking`
--
ALTER TABLE `venue_booking`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audience`
--
ALTER TABLE `audience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `venue`
--
ALTER TABLE `venue`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `venue_booking`
--
ALTER TABLE `venue_booking`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
