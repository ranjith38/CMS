<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Admission Process</h1>
    </header>
    <main>
        <section>
            <h2>Welcome to the Admission Page</h2>
            <p>Here you can find all the information regarding the admission process.</p>
            <!-- Additional content related to admission can be added here -->
        </section>
    </main>
    <footer>
        <p>&copy; 2025 - Your Organization Name</p>
    </footer>
</body>
</html>
