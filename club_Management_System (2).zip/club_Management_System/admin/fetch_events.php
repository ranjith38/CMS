<?php
include 'db_connect.php';

$events = [];
$query = $conn->query("SELECT * FROM events");

while ($row = $query->fetch_assoc()) {
    $events[] = [
        'title' => $row['event_name'],
        'start' => $row['event_date'],
        'allDay' => true
    ];
}

echo json_encode($events);
?>
