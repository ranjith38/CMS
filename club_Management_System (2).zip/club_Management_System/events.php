<?php 
include 'admin/db_connect.php'; 
?>

<style>
#portfolio .img-fluid{
    width: calc(100%);
    height: 30vh;
    z-index: -1;
    position: relative;
    padding: 1em;
}
.venue-list{
    cursor: pointer;
    border: unset;
    flex-direction: inherit;
}
.venue-list .carousel, .venue-list .card-body {
    background-color: skyblue;
    width: calc(50%);
    box-shadow: 6px 6px 10px rgba(0, 0.5, 0, 0.5); /* Adds a soft shadow */

}
.venue-list .carousel img.d-block.w-100 {
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    min-height: 50vh;
    box-shadow: 6px 6px 10px rgba(0.5, 0, 0, 0.56); /* Adds a soft shadow */

}
span.hightlight{
    background: yellow;
}
.carousel,.carousel-inner,.carousel-item{
    min-height: calc(100%);
}
header.masthead, header.masthead:before {
    min-height: 50vh !important;
    height: 50vh !important;
}
.row-items{
    position: relative;
}
.card-left{
    left:0;
}
.card-right{
    right:0;
}
.rtl{
    direction: rtl;
}
.venue-text{
    justify-content: center;
    align-items: center;
}
</style>

<header class="masthead"></header>

<div class="container-fluid mt-3 pt-2">
    <h4 class="text-center text-black">List of Events</h4>
    <hr class="divider">
    
    <div class="row-items">
        <div class="col-lg-12">
            <div class="row">
                <?php
                $events = $conn->query("
                    SELECT e.*, v.venue, v.category, v.address 
                    FROM events e 
                    INNER JOIN venue v ON e.venue_id = v.id
                    ORDER BY e.schedule DESC
                ");
                $ci = 0;
                while($row = $events->fetch_assoc()):
                    $ci++;
                    $rtl = ($ci % 2 == 0) ? 'rtl' : '';
                    $event_date = strtotime($row['schedule']);
                    $today = strtotime(date('Y-m-d H:i:s'));
                    $is_upcoming = $event_date >= $today;
                ?>
                <div class="col-md-6">
                    <div class="card venue-list <?php echo $rtl ?>" data-id="<?php echo $row['id'] ?>">
                        <div id="imagesCarousel_<?php echo $row['id'] ?>" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <?php 
                                $images = [];
                                $fpath = 'admin/assets/uploads/venue_' . $row['venue_id'];
                                if (file_exists($fpath)) {
                                    $images = scandir($fpath);
                                    $i = 0;
                                    foreach ($images as $v) {
                                        if (!in_array($v, array('.', '..'))) {
                                            $active = $i == 0 ? 'active' : '';
                                            echo '
                                                <div class="carousel-item ' . $active . '">
                                                    <img class="d-block w-100" src="' . $fpath . '/' . $v . '" alt="">
                                                </div>
                                            ';
                                            $i++;
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <a class="carousel-control-prev" href="#imagesCarousel_<?php echo $row['id'] ?>" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#imagesCarousel_<?php echo $row['id'] ?>" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>

                        <div class="card-body">
                            <div class="row align-items-center justify-content-center text-center h-100">
                                <div>
                                    <h3><b><?php echo ucwords($row['event']) ?></b></h3>
                                    <small>
                                        <?php echo date('d M Y, h:i A', $event_date) ?> 
                                        (<?php echo $is_upcoming ? '<span style="color: green;">Upcoming</span>' : '<span style="color: red;">Completed</span>'; ?>)
                                    </small>
                                    <p>
                                        <i><?php echo $row['venue'] ?>, <?php echo $row['address'] ?></i>
                                    </p>
                                    <span class="truncate" style="font-size: 1px;"><small><?php echo ($row['description']); ?></small></span>

                                    <br><br>
                                    <?php if ($is_upcoming): ?>
                                        <button class="btn read_more" style="background-color: #8e44ad; border-color: #8e44ad; color: black;" 
    data-id="<?php echo $row['id'] ?>">Read More
</button>
                                    <?php else: ?>
                                        <button class="btn btn-secondary view-details" data-id="<?php echo $row['id'] ?>" style="background-color: #555;">
                                            View Details
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>

<script>
    // Register for upcoming events
    $('.book-venue').click(function(){
        let eventId = $(this).data('id');
        uni_modal("Submit Joining Request", "booking.php?venue_id=" + eventId);
    });

    // View details of completed events
    $('.view-details').click(function(){
        let eventId = $(this).data('id');
        uni_modal("Event Details", "view_events.php?event_id=" + eventId);
    });

    // Open full-size image on click
    $('.venue-list .carousel img').click(function(){
        viewer_modal($(this).attr('src'));
    });
    $('.read_more').click(function(){
         location.href = "index.php?page=view_event&id="+$(this).attr('data-id')
     })
</script>
